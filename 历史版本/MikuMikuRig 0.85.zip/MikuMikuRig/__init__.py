import bpy

from MikuMikuRig.addons.MikuMikuRig.config import __addon_name__
from MikuMikuRig.addons.MikuMikuRig.i18n.dictionary import dictionary
from MikuMikuRig.common.class_loader import auto_load
from MikuMikuRig.common.class_loader.auto_load import add_properties, remove_properties
from MikuMikuRig.common.i18n.dictionary import common_dictionary
from MikuMikuRig.common.i18n.i18n import load_dictionary

# Add-on info
bl_info = {
    "name": "MikuMikuRig",
    "author": "小峰峰哥l",
    "blender": (4, 2, 0),
    "version": (0, 85),
    "description": "MMD骨骼优化工具",
    "tracker_url": "https://space.bilibili.com/2109816568?spm_id_from=333.1007.0.0",
    "support": "COMMUNITY",
    "category": "VIEW_3D"
}

_addon_properties = {}


def register():
    print("registering")
    # Register classes
    auto_load.init()
    auto_load.register()
    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(bl_info["name"]))


def unregister():
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)
    # unRegister classes
    auto_load.unregister()
    remove_properties(_addon_properties)

    print("{} addon is uninstalled.".format(bl_info["name"]))
