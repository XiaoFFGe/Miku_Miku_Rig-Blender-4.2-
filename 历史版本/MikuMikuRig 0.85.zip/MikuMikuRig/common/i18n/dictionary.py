common_dictionary = {
    "zh_CN": {
        ("*", "translation"): "翻译",
    }
}

common_dictionary["zh_HANS"] = common_dictionary["zh_CN"]
