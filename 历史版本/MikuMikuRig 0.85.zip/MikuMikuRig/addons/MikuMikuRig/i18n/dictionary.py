from MikuMikuRig.common.class_loader.auto_load import preprocess_dictionary

dictionary = {
    "zh_CN": {
        ("*", "MMD Arm Optimization tool"): "MMD骨骼优化工具",
        ("Operator", "Optimization MMD Armature"): "优化MMD骨骼",
        ("Operator", "Build a controller"): "生成控制器",
        ("*", "Controller options"): "控制器选项",

    }
}

dictionary = preprocess_dictionary(dictionary)

dictionary["zh_HANS"] = dictionary["zh_CN"]
