import bpy

from MikuMikuRig.addons.MikuMikuRig.config import __addon_name__
from MikuMikuRig.addons.MikuMikuRig.operators.AddonOperators import mmdarmoptOperator
from MikuMikuRig.addons.MikuMikuRig.operators.AddonOperators import polartargetOperator
from MikuMikuRig.addons.MikuMikuRig.operators.AddonOperators import mmrrigOperator
from MikuMikuRig.common.i18n.i18n import i18n

class MMD_Arm_Opt(bpy.types.Panel):
    bl_label = "MMD Arm Optimization tool"
    bl_idname = "SCENE_PT_MMD_Arm_Opt"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    # name of the side panel
    bl_category = "MMR"

    def draw(self, context: bpy.types.Context):

        addon_prefs = context.preferences.addons[__addon_name__].preferences

        # 从上往下排列
        layout = self.layout

        if addon_prefs.boolean:
            # 增加按钮大小并添加图标
            row = layout.row()
            row.scale_y = 1.5  # 这将使按钮的垂直尺寸加倍
            row.operator(polartargetOperator.bl_idname, text="Optimization MMD Armature", icon='BONE_DATA')
            col = layout.column_flow(columns=2)

        else:
            # 增加按钮大小并添加图标
            row = layout.row()
            row.scale_y = 1.5  # 这将使按钮的垂直尺寸加倍
            row.operator(mmdarmoptOperator.bl_idname, text="Optimization MMD Armature", icon='BONE_DATA')

        row1 = layout.row()
        row1.prop(addon_prefs, "boolean", text="是否启用极向目标")

        col = layout.column_flow(columns=2)
        col.scale_y = 1.2

        obj = context.active_object
        if obj:
            # 第五个骨骼和约束组合
            bone_name_1 = "ひじ.L"
            constraint_name_1 = "【IK】L"
            obj = bpy.context.object
            if obj and obj.type == 'ARMATURE':
                bone_1 = obj.pose.bones.get(bone_name_1)
                if bone_1:
                    constraint_1 = bone_1.constraints.get(constraint_name_1)
                    if constraint_1:
                        if addon_prefs.boolean:
                            col.prop(constraint_1, "pole_angle", text="手IK.L(极向角度)")

            # 第二个骨骼和约束组合
            bone_name_2 = "手首.L"
            constraint_name_2 = "【复制旋转】.L"
            if obj and obj.type == 'ARMATURE':
                bone_2 = obj.pose.bones.get(bone_name_2)
                if bone_2:
                    constraint_2 = bone_2.constraints.get(constraint_name_2)
                    if constraint_2:
                        col.prop(constraint_2, "influence",text="手IK.L(旋转)")

            # 第一个骨骼和约束组合
            bone_name_1 = "ひじ.L"
            constraint_name_1 = "【IK】L"
            obj = bpy.context.object
            if obj and obj.type == 'ARMATURE':
                bone_1 = obj.pose.bones.get(bone_name_1)
                if bone_1:
                    constraint_1 = bone_1.constraints.get(constraint_name_1)
                    if constraint_1:
                        col.prop(constraint_1, "influence",text="手IK.L(位置)")

            # 第六个骨骼和约束组合
            bone_name_1 = "ひじ.R"
            constraint_name_1 = "【IK】R"
            obj = bpy.context.object
            if obj and obj.type == 'ARMATURE':
                bone_1 = obj.pose.bones.get(bone_name_1)
                if bone_1:
                    constraint_1 = bone_1.constraints.get(constraint_name_1)
                    if constraint_1:
                        if addon_prefs.boolean:
                            col.prop(constraint_1, "pole_angle", text="手IK.R(极向角度)")

            # 第三个骨骼和约束组合
            bone_name_1 = "ひじ.R"
            constraint_name_1 = "【IK】R"
            obj = bpy.context.object
            if obj and obj.type == 'ARMATURE':
                bone_1 = obj.pose.bones.get(bone_name_1)
                if bone_1:
                    constraint_1 = bone_1.constraints.get(constraint_name_1)
                    if constraint_1:
                        col.prop(constraint_1, "influence", text="手IK.R(位置)")

            # 第四个骨骼和约束组合
            bone_name_2 = "手首.R"
            constraint_name_2 = "【复制旋转】.R"
            if obj and obj.type == 'ARMATURE':
                bone_2 = obj.pose.bones.get(bone_name_2)
                if bone_2:
                    constraint_2 = bone_2.constraints.get(constraint_name_2)
                    if constraint_2:
                        col.prop(constraint_2, "influence", text="手IK.R(旋转)")


    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.active_object is not None


class MMD_Rig_Opt(bpy.types.Panel):
    bl_label = "Controller options"
    bl_idname = "SCENE_PT_MMR_Rig_Opt"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    # name of the side panel
    bl_category = "MMR"

    def draw(self, context: bpy.types.Context):
        addon_prefs = context.preferences.addons[__addon_name__].preferences
        # 从上往下排列
        layout = self.layout

        # 增加按钮大小并添加图标
        row = layout.row()
        row.scale_y = 1.5  # 这将使按钮的垂直尺寸加倍
        row.operator(mmrrigOperator.bl_idname, text="Build a controller",icon='POSE_HLT')


    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.active_object is not None
